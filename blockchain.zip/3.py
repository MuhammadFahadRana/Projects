import tkinter as tk
from tkinter import messagebox
import time
import rsa
import hashlib

class Transaction:
    def __init__(self, sender, recipient, amount, timestamp=None, signature=None):
        self.sender = sender
        self.recipient = recipient
        self.amount = amount
        self.timestamp = timestamp if timestamp else time.time()
        self.signature = signature

    def to_dict(self):
        return {
            'sender': self.sender,
            'recipient': self.recipient,
            'amount': self.amount,
            'timestamp': self.timestamp,
        }

    def sign(self, private_key):
        message = str(self.to_dict()).encode('utf-8')
        self.signature = rsa.sign(message, private_key, 'SHA-256')

    def verify_signature(self, sender_public_key):
        message = str(self.to_dict()).encode('utf-8')
        try:
            return rsa.verify(message, self.signature, sender_public_key)
        except rsa.VerificationError:
            return False

    def __str__(self):
        return f"{self.sender} -> {self.recipient}: {self.amount} BTC at {self.timestamp} with signature {self.signature}"

class Block:
    def __init__(self, index, creator_public_key, previous_hash, transactions, timestamp=None):
        self.index = index
        self.creator_public_key = creator_public_key
        self.previous_hash = previous_hash
        self.transactions = transactions
        self.timestamp = timestamp if timestamp else time.time()
        self.hash = self.calculate_hash()
        self.signature = None

    def calculate_hash(self):
        block_string = f"{self.index}{self.creator_public_key}{self.previous_hash}{self.timestamp}{self.transactions}".encode()
        return hashlib.sha256(block_string).hexdigest()

    def sign_block(self, private_key):
        message = self.hash.encode('utf-8')
        self.signature = rsa.sign(message, private_key, 'SHA-256')

    def verify_block_signature(self):
        try:
            # Convert the stored public key string back to an RSA key object
            creator_public_key = rsa.PublicKey.load_pkcs1(self.creator_public_key.encode())

            message = self.hash.encode('utf-8')
            return rsa.verify(message, self.signature, creator_public_key)
        except rsa.VerificationError:
            return False
        except Exception as e:
            print(f"Error in verifying block signature: {e}")
            return False

    def __str__(self):
        transactions_str = '\n'.join(str(tx) for tx in self.transactions)
        return (f"Block:\nIndex: {self.index}\nCreator Public Key: {self.creator_public_key}\n"
                f"Timestamp: {self.timestamp}\nTransactions:\n{transactions_str}\n"
                f"Previous Hash: {self.previous_hash}\nHash: {self.hash}\nSignature: {self.signature}")
    
    def verify_block(self):
        # Logic to verify the block's integrity
        calculated_hash = self.calculate_hash()
        return calculated_hash == self.hash and self.verify_block_signature()

class Node:
    def __init__(self, name, public_key, private_key, is_authority=False):
        self.name = name
        self.public_key = public_key
        self.private_key = private_key
        self.chain = [self.create_genesis_block()]
        self.pending_transactions = []
        self.is_authority = is_authority
        self.verified_transactions = []  # List to store verified transactions
        self.pending_blocks = []  # List to store pending blocks

    def create_genesis_block(self):
        return Block(0, "genesis_creator_public_key", "genesis_previous_hash", [])

    def verify_and_store_transaction(self, transaction):
        # Check if the node is an authority node
        try:
            sender_public_key_bytes = transaction.sender.encode('utf-8')
            sender_public_key = rsa.PublicKey.load_pkcs1(sender_public_key_bytes, 'PEM')

            if transaction.verify_signature(sender_public_key):
                self.pending_transactions.remove(transaction)  # Remove from pending
                self.verified_transactions.append(transaction)  # Add to verified
                return True
            return False
        except Exception as e:
            print(f"Error in verifying transaction: {e}")
            return False
        
    # New method to get verified transactions
    def get_verified_transactions(self):
        return self.verified_transactions
    
    def create_block(self, creator_public_key):
        # Use verified transactions to create the block
        block = Block(len(self.chain), creator_public_key, self.chain[-1].hash, self.verified_transactions)
        self.chain.append(block)  # Append the new block to the chain
        self.verified_transactions = []  # Clear the verified transactions
        return block
   
    def verify_block(self, block):
        # Verify a block, checking the block's hash, signature, etc.
        try:
            # Verify block's hash
            calculated_hash = hashlib.sha256(str(block).encode()).hexdigest()
            if block.hash != calculated_hash:
                return False

            # Verify block's signature
            return rsa.verify(block.hash.encode('utf-8'), block.signature, block.creator_public_key)
        except Exception as e:
            print(f"Error in verifying block: {e}")
            return False
    
    def add_verified_block(self, block):
        if self.verify_block(block):
            self.chain.append(block)
            return True
        return False
    
    def create_transaction(self, sender, recipient, amount):
        # Since self.public_key is already a PEM-formatted string, use it directly
        sender_public_key_pem = self.public_key

        # Create a new transaction with the PEM-formatted public key
        transaction = Transaction(sender_public_key_pem, recipient, amount)
        sender_private_key = rsa.PrivateKey.load_pkcs1(self.private_key)
        transaction.sign(sender_private_key)
        self.pending_transactions.append(transaction)
        return transaction
    
    def get_pending_transactions(self):
        return self.pending_transactions

    def display_blockchain(self):
        for block in self.chain:
            print(block)

    # Method to display all verified blocks from the blockchain
    def display_verified_blocks(self):
            for block in self.chain:
                if block.verify_block():
                    print(block)
                    
    def display_pending_blocks(self):
            for block in self.pending_blocks:
                if not block.verify_block():
                    print(block)

    def add_block_to_pending(self, block):
            # Assuming you have a list named pending_blocks to store the newly created blocks
            self.pending_blocks.append(block)
            # Implement any additional logic needed when a block is added to pending

def format_public_key_for_display(public_key_pem):
            # Split the key into lines and remove the first and last lines (headers and footers)
            key_lines = public_key_pem.split('\n')
            formatted_key = '\n'.join(key_lines[1:-2])  # Exclude the first and last two lines
            return formatted_key

class BlockchainApp:
    def __init__(self, nodes):
        self.nodes = nodes
        self.current_node = None
        self.root = tk.Tk()
        self.root.title("Fahad's Blockchain")
        self.main_menu()

    def main_menu(self):
        self.clear_window()
        tk.Label(self.root, text="Main Menu:").pack()
        tk.Button(self.root, text="1. Node selection", command=self.node_selection_menu).pack()
        tk.Button(self.root, text="2. Print all verified transactions", command=self.print_verified_transactions).pack()
        tk.Button(self.root, text="3. Print all pending transactions", command=self.print_pending_transactions).pack()
        tk.Button(self.root, text="4. Print all verified blocks in the blockchain", command=self.print_verified_blocks).pack()
        tk.Button(self.root, text="5. Print all pending blocks", command=self.print_pending_blocks).pack()
        tk.Button(self.root, text="6. Exit Program", command=self.root.quit).pack()

    def node_selection_menu(self):
        self.clear_window()
        tk.Label(self.root, text="Select one of the following nodes to perform actions in Menu 1.1:").pack()
        for node in self.nodes:
            tk.Button(self.root, text=node.name, command=lambda n=node: self.select_node_and_show_node_actions(n)).pack()
        tk.Button(self.root, text="3. Exit to Main Menu", command=self.main_menu).pack()

    def select_node_and_show_node_actions(self, node):
        self.current_node = node
        self.node_actions_menu()

    def node_actions_menu(self):
        self.clear_window()
        tk.Label(self.root, text="Node-Specific Actions:").pack()
        tk.Button(self.root, text="1. Create a transaction", command=self.transaction_creation_menu).pack()
        tk.Button(self.root, text="2. Verify a transaction", command=self.verify_transactions_menu).pack()
        tk.Button(self.root, text="3. Create a block if the transactions are valid", command=self.create_block).pack()
        tk.Button(self.root, text="4. Verify block in the blockchain", command=self.verify_block_menu).pack()
        tk.Button(self.root, text="5. Print transactions created by this node", command=self.print_node_created_transactions).pack()
        tk.Button(self.root, text="6. Print pending transactions that this node has not yet verified", command=self.print_node_pending_transactions).pack()
        tk.Button(self.root, text="7. Exit to Node Selection Menu", command=self.node_selection_menu).pack()


    def verify_transactions_menu(self):
        self.clear_window()
        if not self.current_node:
            messagebox.showerror("Error", "No node selected. Please select a node first.")
            self.main_menu()
            return
        
        tk.Label(self.root, text="Verify Transactions:").pack()
        pending_transactions = self.current_node.get_pending_transactions()
        for transaction in pending_transactions:
            transaction_str = str(transaction)
            tk.Label(self.root, text=transaction_str).pack()
            tk.Button(self.root, text="Verify", command=lambda tx=transaction: self.verify_transaction(tx)).pack()
        tk.Button(self.root, text="Back", command=self.main_menu).pack()
    
    def verify_transaction(self, transaction):
        if self.current_node.verify_and_store_transaction(transaction):
            messagebox.showinfo("Transaction Verified", "Transaction has been verified and stored.")
        else:
            messagebox.showerror("Verification Failed", "Transaction verification failed.")
        self.verify_transactions_menu()
    
    
    def select_node(self, node):
        self.current_node = node
        messagebox.showinfo("Node Selection", f"{node.name} has been selected.")
        self.main_menu()

    def create_block(self):
        if not self.current_node:
            messagebox.showerror("Error", "No node selected. Please select a node first.")
            self.main_menu()
            return
        new_block = self.current_node.create_block(self.current_node.public_key)
        
        # Add the new block to the pending blocks list of all nodes
        for node in self.nodes:
            node.add_block_to_pending(new_block)

        messagebox.showinfo("Block Created", f"Block {new_block.index} has been successfully created!")
        self.main_menu()

    def print_verified_transactions(self):
        self.clear_window()
        if not self.current_node:
            messagebox.showerror("Error", "No node selected. Please select a node first.")
            self.main_menu()
            return
        tk.Label(self.root, text="Verified Transactions:").pack()
        verified_transactions = self.current_node.get_verified_transactions()
        for transaction in verified_transactions:
            tk.Label(self.root, text=str(transaction)).pack()
        tk.Button(self.root, text="Back", command=self.main_menu).pack()
    
    def print_blocks(self):
        self.clear_window()
        tk.Label(self.root, text="Blockchain:").pack()
        for node in self.nodes:
            node.display_blockchain()
        self.main_menu()
    
    def print_verified_blocks(self):
        # Logic to print verified blocks
        if self.current_node:
            self.current_node.display_verified_blocks()
        else:
            messagebox.showerror("Error", "No node selected. Please select a node first.")
        self.main_menu()

    def print_pending_blocks(self):
        # Logic to print pending blocks
        if self.current_node:
            self.current_node.display_pending_blocks()
        else:
            messagebox.showerror("Error", "No node selected. Please select a node first.")
        self.main_menu()

    def transaction_creation_menu(self):
        self.clear_window()
        if not self.current_node:
            messagebox.showerror("Error", "No node selected. Please select a node first.")
            self.main_menu()
            return

        # Labels and entries for each field: Sender, Recipient, Amount
        tk.Label(self.root, text="Create a Transaction").grid(row=0, columnspan=3)
        
        tk.Label(self.root, text="Sender:").grid(row=1, column=0)
        sender_entry = tk.Entry(self.root)
        sender_entry.grid(row=1, column=1)
        sender_entry.insert(0, "")

        tk.Label(self.root, text="Recipient:").grid(row=2, column=0)
        recipient_entry = tk.Entry(self.root)
        recipient_entry.grid(row=2, column=1)
        recipient_entry.insert(0, "")

        tk.Label(self.root, text="Amount:").grid(row=3, column=0)
        amount_entry = tk.Entry(self.root)
        amount_entry.grid(row=3, column=1)
        amount_entry.insert(0, "")

        
        tk.Button(self.root, text="Submit", command=lambda: self.create_transaction(sender_entry.get(), recipient_entry.get(), amount_entry.get())).grid(row=4, column=0, columnspan=2)
        tk.Button(self.root, text="Back", command=self.main_menu).grid(row=4, column=2)

    def verify_block_menu(self):
        self.clear_window()
        if not self.current_node:
            messagebox.showerror("Error", "No node selected. Please select a node first.")
            self.main_menu()
            return

        tk.Label(self.root, text="Verify Block:").pack()
        # Assuming there's a list of blocks to verify
        for block in self.current_node.pending_blocks:
            block_str = str(block)
            tk.Label(self.root, text=block_str).pack()
            tk.Button(self.root, text="Verify", command=lambda b=block: self.verify_block(b)).pack()
        tk.Button(self.root, text="Back", command=self.main_menu).pack()

    def verify_block(self, block):
        if self.current_node.add_verified_block(block):
            messagebox.showinfo("Block Verification", "Block has been verified and added to the blockchain.")
        else:
            messagebox.showerror("Verification Failed", "Block verification failed.")
        self.verify_block_menu()

    def create_transaction(self, sender, recipient, amount):
        try:
            amount = float(amount)

            # Retrieve the current node's public key in PEM format
            sender_public_key_pem = self.current_node.public_key
            formatted_sender_key = format_public_key_for_display(sender_public_key_pem)

            # Create the transaction
            transaction = self.current_node.create_transaction(sender_public_key_pem, recipient, amount)

            # Format the transaction details for display
            transaction_display = f"Sender: {sender}\nRecipient: {recipient}\nRSA Key:\n{formatted_sender_key}"

            # Display the transaction details in a messagebox
            messagebox.showinfo("Transaction", "Transaction has been created:\n" + transaction_display)
        except ValueError:
            messagebox.showerror("Transaction Error", "Invalid amount, please enter a number.")
        self.main_menu()

    def print_pending_transactions(self):
        self.clear_window()
        if not self.current_node:
            messagebox.showerror("Error", "No node selected. Please select a node first.")
            self.main_menu()
            return
        tk.Label(self.root, text="Pending Transactions:").pack()
        pending_transactions = self.current_node.get_pending_transactions()
        for transaction in pending_transactions:
            tk.Label(self.root, text=str(transaction)).pack()
        tk.Button(self.root, text="Back", command=self.main_menu).pack()

    def verify_block_menu(self):
        self.clear_window()
        if not self.current_node:
            messagebox.showerror("Error", "No node selected. Please select a node first.")
            self.main_menu()
            return
        
        tk.Label(self.root, text="Verify Blocks:").pack()
        for block in self.current_node.pending_blocks:
            block_str = f"Block Index: {block.index}, Transactions: {len(block.transactions)}"
            tk.Label(self.root, text=block_str).pack()
            tk.Button(self.root, text="Verify", command=lambda b=block: self.verify_block(b)).pack()
        tk.Button(self.root, text="Back", command=self.node_actions_menu).pack()

    def verify_block(self, block):
        if self.current_node.verify_block(block):
            messagebox.showinfo("Block Verified", "Block has been verified and added to the blockchain.")
            self.current_node.pending_blocks.remove(block)
        else:
            messagebox.showerror("Verification Failed", "Block verification failed.")
        self.verify_block_menu()
    
    def print_node_created_transactions(self):
        self.clear_window()
        if not self.current_node:
            messagebox.showerror("Error", "No node selected. Please select a node first.")
            self.main_menu()
            return

        tk.Label(self.root, text="Transactions Created by This Node:").pack()
        for transaction in self.current_node.verified_transactions:
            tk.Label(self.root, text=str(transaction)).pack()
        tk.Button(self.root, text="Back", command=self.node_actions_menu).pack()
    
    def print_node_pending_transactions(self):
        self.clear_window()
        if not self.current_node:
            messagebox.showerror("Error", "No node selected. Please select a node first.")
            self.main_menu()
            return

        tk.Label(self.root, text="Pending Transactions (Not Yet Verified by This Node):").pack()
        for transaction in self.current_node.pending_transactions:
            tk.Label(self.root, text=str(transaction)).pack()
        tk.Button(self.root, text="Back", command=self.node_actions_menu).pack()

    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    # Generate RSA key pairs for the authority node and two other nodes.
    # Each key pair consists of a public key and a private key.
    # The key size is 512 bits, which is a parameter for the RSA algorithm.
    # (authority_pub_key, authority_priv_key) = rsa.newkeys(512)
    (node1_pub_key, node1_priv_key) = rsa.newkeys(512)
    (node2_pub_key, node2_priv_key) = rsa.newkeys(512)

    # Convert the public keys to PEM format and store them as strings.
    # PEM (Privacy-Enhanced Mail) is a base64 encoded DER certificate.
    # save_pkcs1() converts the RSA key to PEM format.
    # decode() converts the bytes object to a string for easy storage and manipulation.
    # Create the nodes, marking at least one as an authority node
    # authority_node = Node("Authority Node", authority_pub_key.save_pkcs1().decode(), authority_priv_key.save_pkcs1().decode(), is_authority=True)
    node1 = Node("Node 1", node1_pub_key.save_pkcs1().decode(), node1_priv_key.save_pkcs1().decode())
    node2 = Node("Node 2", node2_pub_key.save_pkcs1().decode(), node2_priv_key.save_pkcs1().decode())
  
    # Create a list of the nodes. This list is then passed to the BlockchainApp class.
    nodes = [node1, node2]

    # Start the blockchain application. This call will start the Tkinter event loop.
    # The Tkinter GUI will remain open until the user decides to exit the application.
    app = BlockchainApp(nodes)
    app.run()