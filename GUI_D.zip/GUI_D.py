import tkinter as tk
from tkinter import ttk
import random
from sympy import mod_inverse, isprime

# RSA key generation function
def generate_RSA_key_pair(bits):
    def generate_prime(bits):
        while True:
            number = random.getrandbits(bits)
            if isprime(number):
                return number

    p = generate_prime(bits // 2)
    q = generate_prime(bits // 2)
    while p == q:
        q = generate_prime(bits // 2)

    N = p * q
    phi_N = (p - 1) * (q - 1)

    e = random.randint(2, phi_N - 1)
    while True:
        if isprime(e) and phi_N % e != 0:
            break
        e = random.randint(2, phi_N - 1)

    d = mod_inverse(e, phi_N)

    return (e, N), (d, N)

# Decryption function
def decrypt_message(ciphertext, private_key):
    d, N = private_key
    return ''.join([chr(pow(char, d, N)) for char in ciphertext])

# Function to perform decryption
def perform_decryption():
    ciphertext_str = ciphertext_entry.get()
    ciphertext_list = list(map(int, ciphertext_str.split(',')))
    decrypted_message = decrypt_message(ciphertext_list, private_key)

    decrypted_label.config(text="Decrypted: " + decrypted_message)

# Generate RSA key pair
public_key, private_key = generate_RSA_key_pair(2048)

# Create the main window
root = tk.Tk()
root.title("RSA Decryption for Telemedicine")

# Create widgets
ciphertext_label = ttk.Label(root, text="Enter ciphertext (comma-separated integers):")
ciphertext_entry = ttk.Entry(root, width=60)
decrypt_button = ttk.Button(root, text="Decrypt", command=perform_decryption)
decrypted_label = ttk.Label(root, text="Decrypted: ")

# Place widgets on a grid
ciphertext_label.grid(row=0, column=0, sticky="w")
ciphertext_entry.grid(row=0, column=1)
decrypt_button.grid(row=1, columnspan=2)
decrypted_label.grid(row=2, columnspan=2, sticky="w")

# Start the Tkinter event loop
root.mainloop()