import math

import tkinter as tk
from tkinter import ttk
import random
from sympy import mod_inverse, isprime

# RSA key generation function
def generate_RSA_key_pair(bits):
    def generate_prime(bits):
        while True:
            number = random.getrandbits(bits)
            if isprime(number):
                return number

    p = generate_prime(bits // 2)
    q = generate_prime(bits // 2)
    while p == q:
        q = generate_prime(bits // 2)

    N = p * q
    phi_N = (p - 1) * (q - 1)

    e = random.randint(2, phi_N - 1)
    while True:
        if isprime(e) and phi_N % e != 0:
            break
        e = random.randint(2, phi_N - 1)

    d = mod_inverse(e, phi_N)

    return (e, N), (d, N)

# Encryption function
def encrypt_message(plaintext, public_key):
    e, N = public_key
    return [pow(ord(char), e, N) for char in plaintext]

# Decryption function
def decrypt_message(ciphertext, private_key):
    d, N = private_key
    return ''.join([chr(pow(char, d, N)) for char in ciphertext])

# Function to perform encryption and decryption
def perform_crypto():
    plaintext = plaintext_entry.get()
    
    public_key, private_key = generate_RSA_key_pair(2048) #change the value of the key here 3072, 4096

    ciphertext = encrypt_message(plaintext, public_key)
    decrypted_message = decrypt_message(ciphertext, private_key)

    plaintext_label.config(text="Plaintext: " + str(plaintext))
    ciphertext_label.config(text="Ciphertext: " + str(ciphertext))
    decrypted_label.config(text="Decrypted: " + decrypted_message)

# Create the main window
root = tk.Tk()
root.title("RSA Encryption for Telemedicine")

# Create widgets
plaintext_label = ttk.Label(root, text="Enter plaintext:")
plaintext_entry = ttk.Entry(root, width=40)
encrypt_button = ttk.Button(root, text="Encrypt & Decrypt", command=perform_crypto) #Change 'text' as per the function
ciphertext_label = ttk.Label(root, text="Ciphertext: ")
decrypted_label = ttk.Label(root, text="Decrypted: ")

# Place widgets on a grid
plaintext_label.grid(row=0, column=0, sticky="w")
plaintext_entry.grid(row=0, column=1)
encrypt_button.grid(row=1, columnspan=1)
ciphertext_label.grid(row=2, columnspan=1, sticky="w")
decrypted_label.grid(row=3, columnspan=1, sticky="w")


# Start the Tkinter event loop
root.mainloop()