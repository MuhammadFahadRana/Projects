import random
from sympy import mod_inverse, isprime

# Function to generate a prime number of 'bits' bits
def generate_prime(bits):
    while True:
        number = random.getrandbits(bits)
        if isprime(number):
            return number

# Function to generate RSA key pairs
def generate_RSA_key_pair(bits):
    p = generate_prime(bits // 2)
    q = generate_prime(bits // 2)
    while p == q:
        q = generate_prime(bits // 2)

    N = p * q
    phi_N = (p - 1) * (q - 1)

    e = random.randint(2, phi_N - 1)
    while True:
        if isprime(e) and phi_N % e != 0:
            break
        e = random.randint(2, phi_N - 1)

    d = mod_inverse(e, phi_N)

    return (e, N), (d, N)

# Function to encrypt a plaintext message
def encrypt_message(plaintext, public_key):
    e, N = public_key
    ciphertext = [pow(ord(char), e, N) for char in plaintext]
    return ciphertext

# Function to decrypt a ciphertext message
def decrypt_message(ciphertext, private_key):
    d, N = private_key
    plaintext = ''.join([chr(pow(char, d, N)) for char in ciphertext])
    return plaintext

if __name__ == "__main__":
    # Key length in bits
    key_length = 2048  # Suitable for secure communications

    # Generate RSA key pair
    public_key, private_key = generate_RSA_key_pair(key_length)

    # Display the keys
    print("Public Key:", public_key)
    print("Private Key:", private_key)

    # Take a plaintext message as input
    plaintext = input("Enter a plaintext message: ")

    # Encrypt the message
    ciphertext = encrypt_message(plaintext, public_key)
    print("Encrypted message:", ciphertext)

    # Decrypt the message
    decrypted_message = decrypt_message(ciphertext, private_key)
    print("Decrypted message:", decrypted_message)